package org.example;

public class AgePriceCalculator {

    public int calculatePrice(int age) {

        if (age < 0) {
            throw new IllegalArgumentException("Age must be >= 0");
        }

        if (age < 6) {
            return 0;
        } else if (age <= 17) {
            return 50000;
        } else if (age <= 60) {
            return 100000;
        } else {
            return 70000;
        }
    }
}
