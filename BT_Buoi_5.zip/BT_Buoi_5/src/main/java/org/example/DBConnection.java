package org.example;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(
                "jdbc:sqlserver://DESKTOP-D6KNUQ5\\SQLSV_CON1:1433;databaseName=Lab5Register;encrypt=true;trustServerCertificate=true",
                "sa",
                "123"
        );
    }
}
