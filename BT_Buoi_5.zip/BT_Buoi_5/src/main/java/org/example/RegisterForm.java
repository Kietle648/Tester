package org.example;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class RegisterForm extends JFrame {

    PlaceholderTextField txtId =
            new PlaceholderTextField("6-10 ký tự, chỉ chữ và số");
    PlaceholderTextField txtName =
            new PlaceholderTextField("Nhập họ tên đầy đủ");
    PlaceholderTextField txtEmail =
            new PlaceholderTextField("vd: nguyenvana@gmail.com");
    PlaceholderTextField txtPhone =
            new PlaceholderTextField("Bắt đầu bằng 0, 10-12 số");
    JTextArea txtAddress = new JTextArea(3,20);
    JPasswordField txtPass = new JPasswordField();
    JPasswordField txtConfirm = new JPasswordField();
    PlaceholderTextField txtBirth =
            new PlaceholderTextField("yyyy-mm-dd");

    JRadioButton rdNam = new JRadioButton("Nam");
    JRadioButton rdNu = new JRadioButton("Nữ");
    JRadioButton rdKhac = new JRadioButton("Khác");

    JCheckBox chkAgree =
            new JCheckBox("Tôi đồng ý với các điều khoản dịch vụ");

    JLabel eId=new JLabel();
    JLabel eName=new JLabel();
    JLabel eEmail=new JLabel();
    JLabel ePhone=new JLabel();
    JLabel eAddress=new JLabel();
    JLabel ePass=new JLabel();
    JLabel eConfirm=new JLabel();
    JLabel eBirth=new JLabel();
    JLabel msg=new JLabel();

    RegisterValidator v = new RegisterValidator();

    public RegisterForm(){

        setTitle("ĐĂNG KÝ TÀI KHOẢN KHÁCH HÀNG");
        setSize(620,720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel=new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(0,120,215),2),
                        BorderFactory.createEmptyBorder(
                                20,20,20,20)
                )
        );

        GridBagConstraints g=new GridBagConstraints();
        g.insets=new Insets(6,10,6,10);
        g.fill=GridBagConstraints.HORIZONTAL;

        JLabel title=new JLabel("ĐĂNG KÝ TÀI KHOẢN KHÁCH HÀNG");
        title.setFont(new Font("Segoe UI",Font.BOLD,22));
        title.setHorizontalAlignment(JLabel.CENTER);

        g.gridx=0; g.gridy=0; g.gridwidth=2;
        panel.add(title,g);
        g.gridwidth=1;

        style(txtId);
        style(txtName);
        style(txtEmail);
        style(txtPhone);
        style(txtBirth);
        style(txtPass);
        style(txtConfirm);

        txtAddress.setBorder(new RoundedBorder(10));
        txtAddress.setLineWrap(true);

        setErrorColor();

        int r = 1;

        addRow(panel,g,r,"Mã Khách Hàng *",txtId,eId); r+=2;
        addRow(panel,g,r,"Họ và Tên *",txtName,eName); r+=2;
        addRow(panel,g,r,"Email *",txtEmail,eEmail); r+=2;
        addRow(panel,g,r,"Số điện thoại *",txtPhone,ePhone); r+=2;

        // Địa chỉ
        g.gridx=0; g.gridy=r;
        panel.add(new JLabel("Địa chỉ *"),g);
        g.gridx=1;
        panel.add(new JScrollPane(txtAddress),g);
        g.gridx=1; g.gridy=r+1;
        panel.add(eAddress,g);
        r+=2;

        addRow(panel,g,r,"Mật khẩu *",txtPass,ePass); r+=2;
        addRow(panel,g,r,"Xác nhận mật khẩu *",txtConfirm,eConfirm); r+=2;
        addRow(panel,g,r,"Ngày sinh",txtBirth,eBirth); r+=2;

        g.gridx=0; g.gridy=r;
        panel.add(new JLabel("Giới tính"),g);

        JPanel genderPanel=new JPanel();
        genderPanel.setBackground(Color.WHITE);
        ButtonGroup bg=new ButtonGroup();
        bg.add(rdNam);
        bg.add(rdNu);
        bg.add(rdKhac);
        genderPanel.add(rdNam);
        genderPanel.add(rdNu);
        genderPanel.add(rdKhac);

        g.gridx=1;
        panel.add(genderPanel,g);
        r++;

        g.gridx=1; g.gridy=r;
        panel.add(chkAgree,g);
        r++;

        JButton btnReg=new JButton("Đăng ký");
        JButton btnReset=new JButton("Nhập lại");

        btnReg.setBackground(new Color(0,123,255));
        btnReg.setForeground(Color.WHITE);
        btnReg.setFocusPainted(false);

        btnReset.setBackground(Color.GRAY);
        btnReset.setForeground(Color.WHITE);

        JPanel btnPanel=new JPanel();
        btnPanel.setBackground(Color.WHITE);
        btnPanel.add(btnReg);
        btnPanel.add(btnReset);

        g.gridx=0; g.gridy=r; g.gridwidth=2;
        panel.add(btnPanel,g);
        r++;

        msg.setHorizontalAlignment(JLabel.CENTER);
        g.gridy=r;
        panel.add(msg,g);

        btnReg.addActionListener(e->register());
        btnReset.addActionListener(e->reset());

        add(panel);
        setVisible(true);
    }

    void style(JComponent c){
        c.setBorder(new RoundedBorder(10));
        c.setFont(new Font("Segoe UI",Font.PLAIN,13));
    }

    void setErrorColor(){
        JLabel[] arr={eId,eName,eEmail,ePhone,
                eAddress,ePass,eConfirm,eBirth};
        for(JLabel l:arr){
            l.setForeground(Color.RED);
            l.setFont(new Font("Segoe UI",Font.ITALIC,12));
        }
    }

    void addRow(JPanel p, GridBagConstraints g,
                int baseRow,
                String label,
                JComponent field,
                JLabel err){

        g.gridx=0; g.gridy=baseRow;
        p.add(new JLabel(label),g);

        g.gridx=1;
        p.add(field,g);

        g.gridx=1; g.gridy=baseRow+1;
        p.add(err,g);
    }

    void register(){
        clearError();
        boolean ok=true;

        if(!v.customerId(txtId.getText())){
            eId.setText("6-10 ký tự chữ và số, không trùng");
            ok=false;
        }
        if(!v.name(txtName.getText())){
            eName.setText("5-50 ký tự");
            ok=false;
        }
        if(!v.email(txtEmail.getText())){
            eEmail.setText("Email không hợp lệ");
            ok=false;
        }
        if(!v.phone(txtPhone.getText())){
            ePhone.setText("Bắt đầu 0, 10-12 số");
            ok=false;
        }
        if(!v.address(txtAddress.getText())){
            eAddress.setText("Không vượt 255 ký tự");
            ok=false;
        }
        if(!v.password(new String(txtPass.getPassword()))){
            ePass.setText("Ít nhất 8 ký tự");
            ok=false;
        }
        if(!v.match(
                new String(txtPass.getPassword()),
                new String(txtConfirm.getPassword()))){
            eConfirm.setText("Không khớp");
            ok=false;
        }

        try{
            LocalDate d=LocalDate.parse(txtBirth.getText());
            if(!v.birth(d)){
                eBirth.setText("Chưa đủ 18 tuổi");
                ok=false;
            }
        }catch(Exception ex){
            eBirth.setText("Sai định dạng yyyy-mm-dd");
            ok=false;
        }

        if(!chkAgree.isSelected()){
            msg.setForeground(Color.RED);
            msg.setText("Bạn phải đồng ý điều khoản");
            ok=false;
        }

        if(ok){
            Customer c=new Customer();
            c.id=txtId.getText();
            c.name=txtName.getText();
            c.email=txtEmail.getText();
            c.phone=txtPhone.getText();
            c.address=txtAddress.getText();
            c.password=new String(txtPass.getPassword());

            new CustomerDAO().insert(c);

            msg.setForeground(new Color(0,150,0));
            msg.setText("Đăng ký thành công!");
        }
    }

    void clearError(){
        eId.setText(""); eName.setText("");
        eEmail.setText(""); ePhone.setText("");
        eAddress.setText(""); ePass.setText("");
        eConfirm.setText(""); eBirth.setText("");
        msg.setText("");
    }

    void reset(){
        txtId.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtAddress.setText("");
        txtPass.setText("");
        txtConfirm.setText("");
        txtBirth.setText("");
        chkAgree.setSelected(false);
        clearError();
    }

    public static void main(String[] args){
        new RegisterForm();
    }
}
