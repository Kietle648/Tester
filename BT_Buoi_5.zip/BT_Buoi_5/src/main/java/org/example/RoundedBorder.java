package org.example;

import javax.swing.border.Border;
import java.awt.*;

public class RoundedBorder implements Border {

    int radius;

    public RoundedBorder(int r){
        radius=r;
    }

    public Insets getBorderInsets(Component c){
        return new Insets(8,8,8,8);
    }

    public boolean isBorderOpaque(){ return false; }

    public void paintBorder(Component c, Graphics g,
                            int x,int y,int w,int h){
        g.drawRoundRect(x,y,w-1,h-1,radius,radius);
    }
}
