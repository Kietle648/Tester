package org.example;

public class Customer {
    public String id,name,email,phone,address,password;
}
