package org.example;

public class Main {
    public static void main(String[] args) {
        MathFunc m = new MathFunc();
        System.out.println("5! = " + m.factorial(5));
        System.out.println("5 + 3 = " + m.plus(5,3));
    }
}
