package org.example;

import java.time.*;

public class RegisterValidator {

    CustomerDAO dao=new CustomerDAO();

    public boolean customerId(String s){
        return s.matches("[A-Za-z0-9]{6,10}")
                && !dao.existsCustomerId(s);
    }

    public boolean name(String s){
        return s.matches("[\\p{L} ]{5,50}");
    }

    public boolean email(String s){
        return s.matches("^[\\w.-]+@[\\w.-]+\\.[A-Za-z]{2,}$")
                && !dao.existsEmail(s);
    }

    public boolean phone(String s){
        return s.matches("0\\d{9,11}");
    }

    public boolean address(String s){
        return !s.isEmpty() && s.length()<=255;
    }

    public boolean password(String s){
        return s.length()>=8;
    }

    public boolean match(String p1,String p2){
        return p1.equals(p2);
    }

    public boolean birth(LocalDate d){
        return Period.between(d,LocalDate.now()).getYears()>=18;
    }
}
