package org.example;

import javax.swing.*;
import java.awt.*;

public class PlaceholderTextField extends JTextField {

    String placeholder;

    public PlaceholderTextField(String placeholder){
        this.placeholder=placeholder;
    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        if(getText().isEmpty()){
            Graphics2D g2=(Graphics2D)g;
            g2.setColor(Color.GRAY);
            g2.drawString(placeholder, 5, 17);
        }
    }
}
