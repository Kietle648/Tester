package org.example;

import java.sql.*;

public class CustomerDAO {

    public boolean existsCustomerId(String id){
        try(Connection c=DBConnection.getConnection()){
            PreparedStatement ps=c.prepareStatement(
                    "SELECT 1 FROM Customers WHERE CustomerId=?");
            ps.setString(1,id);
            return ps.executeQuery().next();
        }catch(Exception e){return false;}
    }

    public boolean existsEmail(String email){
        try(Connection c=DBConnection.getConnection()){
            PreparedStatement ps=c.prepareStatement(
                    "SELECT 1 FROM Customers WHERE Email=?");
            ps.setString(1,email);
            return ps.executeQuery().next();
        }catch(Exception e){return false;}
    }

    public void insert(Customer c){
        try(Connection conn=DBConnection.getConnection()){
            PreparedStatement ps=conn.prepareStatement(
                    "INSERT INTO Customers VALUES(?,?,?,?,?,?)");
            ps.setString(1,c.id);
            ps.setString(2,c.name);
            ps.setString(3,c.email);
            ps.setString(4,c.phone);
            ps.setString(5,c.address);
            ps.setString(6,c.password);
            ps.executeUpdate();
        }catch(Exception e){e.printStackTrace();}
    }
}
