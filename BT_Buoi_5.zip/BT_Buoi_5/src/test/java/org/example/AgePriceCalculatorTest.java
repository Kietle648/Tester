package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class AgePriceCalculatorTest {

    AgePriceCalculator calc = new AgePriceCalculator();

    @Test
    public void testFreeTicket() {
        assertEquals(0, calc.calculatePrice(5));
    }

    @Test
    public void testChildPrice() {
        assertEquals(50000, calc.calculatePrice(10));
    }

    @Test
    public void testAdultPrice() {
        assertEquals(100000, calc.calculatePrice(30));
    }

    @Test
    public void testOldPrice() {
        assertEquals(70000, calc.calculatePrice(65));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativeAge() {
        calc.calculatePrice(-3);
    }
}
