package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class SuiteTest1 {

    @Test
    public void testMessage1() {
        System.out.println("SuiteTest1 - Test 1");
        assertEquals("HELLO", "HELLO");
    }

    @Test
    public void testMessage2() {
        System.out.println("SuiteTest1 - Test 2");
        assertTrue(5 > 1);
    }
}
