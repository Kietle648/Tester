package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class SuiteTest2 {

    @Test
    public void testNumber() {
        System.out.println("SuiteTest2 - Test 1");
        assertEquals(10, 5 + 5);
    }

    @Test
    public void testBoolean() {
        System.out.println("SuiteTest2 - Test 2");
        assertFalse(5 < 1);
    }
}
