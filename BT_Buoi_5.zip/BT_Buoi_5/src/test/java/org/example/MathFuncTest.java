package org.example;

import org.junit.*;
import static org.junit.Assert.*;

public class MathFuncTest {

    MathFunc mathFunc;

    @Before
    public void setUp() {
        mathFunc = new MathFunc();
        System.out.println("Before Test");
    }

    @After
    public void tearDown() {
        System.out.println("After Test");
    }

    // Kiểm tra số lần gọi hàm
    @Test
    public void calls() {
        mathFunc.plus(1, 2);
        mathFunc.factorial(3);
        assertEquals(2, mathFunc.calls);
    }

    // Kiểm tra giai thừa
    @Test
    public void factorial() {
        assertEquals(120, mathFunc.factorial(5));
    }

    // Kiểm tra số âm
    @Test(expected = IllegalArgumentException.class)
    public void factorialNegative() {
        mathFunc.factorial(-2);
    }

    // Kiểm tra phép cộng
    @Test
    public void todo() {
        assertEquals(10, mathFunc.plus(5, 5));
    }

    // Bỏ qua test case
    @Ignore
    @Test
    public void ignoreTest() {
        assertEquals(0, mathFunc.plus(0, 0));
    }
}
