package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class RegisterValidatorTest {

    RegisterValidator v = new RegisterValidator();

    // Mã KH
    @Test
    public void testValidCustomerId() {
        assertTrue(v.isValidCustomerId("ABC123"));
    }

    @Test
    public void testInvalidCustomerId() {
        assertFalse(v.isValidCustomerId("A1"));
    }

    // Họ tên
    @Test
    public void testValidName() {
        assertTrue(v.isValidName("Nguyen Van A"));
    }

    // Email
    @Test
    public void testValidEmail() {
        assertTrue(v.isValidEmail("test@gmail.com"));
    }

    @Test
    public void testInvalidEmail() {
        assertFalse(v.isValidEmail("abc.com"));
    }

    // Phone
    @Test
    public void testValidPhone() {
        assertTrue(v.isValidPhone("0123456789"));
    }

    @Test
    public void testInvalidPhone() {
        assertFalse(v.isValidPhone("12345"));
    }

    // Password
    @Test
    public void testValidPassword() {
        assertTrue(v.isValidPassword("12345678"));
    }

    // Confirm password
    @Test
    public void testPasswordMatch() {
        assertTrue(v.isPasswordMatch("12345678","12345678"));
    }

    // Age
    @Test
    public void testValidAge() {
        assertTrue(v.isValidAge(20));
    }

    @Test
    public void testInvalidAge() {
        assertFalse(v.isValidAge(15));
    }
}
