﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Bai4_Buoi4;
using System;

namespace Bai4_Buoi4.Tests
{
    [TestClass]
    public class HinhChuNhatTests
    {
        [TestMethod]
        public void DienTich_ValidRectangle_ReturnsCorrect()
        {
            var tl = new Diem(0, 10);
            var br = new Diem(5, 0);
            var rect = new HinhChuNhat(tl, br);

            double area = rect.DienTich();

            Assert.AreEqual(50, area);
        }

        [TestMethod]
        public void GiaoNhau_TwoRectanglesIntersect_ReturnsTrue()
        {
            var r1 = new HinhChuNhat(new Diem(0, 10), new Diem(5, 0));
            var r2 = new HinhChuNhat(new Diem(3, 8), new Diem(8, 2));

            bool result = r1.GiaoNhau(r2);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void GiaoNhau_TwoRectanglesDoNotIntersect_ReturnsFalse()
        {
            var r1 = new HinhChuNhat(new Diem(0, 10), new Diem(5, 0));
            var r2 = new HinhChuNhat(new Diem(6, 8), new Diem(10, 2));

            bool result = r1.GiaoNhau(r2);

            Assert.IsFalse(result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Constructor_InvalidRectangle_ThrowsException()
        {
            var tl = new Diem(5, 5);
            var br = new Diem(2, 8); // sai logic
            var rect = new HinhChuNhat(tl, br);
        }
    }
}
