﻿using System;

namespace Bai4_Buoi4
{
    public class HinhChuNhat
    {
        public Diem TopLeft { get; }
        public Diem BottomRight { get; }

        public HinhChuNhat(Diem topLeft, Diem bottomRight)
        {
            if (topLeft.X >= bottomRight.X || topLeft.Y <= bottomRight.Y)
                throw new ArgumentException("Invalid Rectangle");

            TopLeft = topLeft;
            BottomRight = bottomRight;
        }

        public double DienTich()
        {
            double width = BottomRight.X - TopLeft.X;
            double height = TopLeft.Y - BottomRight.Y;
            return width * height;
        }

        public bool GiaoNhau(HinhChuNhat other)
        {
            // Không giao nhau nếu một hình nằm hoàn toàn bên trái / phải / trên / dưới hình kia
            if (this.BottomRight.X <= other.TopLeft.X ||
                this.TopLeft.X >= other.BottomRight.X ||
                this.TopLeft.Y <= other.BottomRight.Y ||
                this.BottomRight.Y >= other.TopLeft.Y)
                return false;

            return true;
        }
    }
}
