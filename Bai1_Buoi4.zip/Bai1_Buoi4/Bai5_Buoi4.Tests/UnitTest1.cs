﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Bai5_Buoi4;
using System.Collections.Generic;
using System;

namespace Bai5_Buoi4.Tests
{
    [TestClass]
    public class HocVienTests
    {
        [TestMethod]
        public void DatHocBong_ValidStudent_ReturnsTrue()
        {
            var hv = new HocVien("SV01", "Nguyen Van A", "Ha Noi",
                new double[] { 8.5, 8.0, 9.0 });

            Assert.IsTrue(hv.DatHocBong());
        }

        [TestMethod]
        public void DatHocBong_AverageBelowEight_ReturnsFalse()
        {
            var hv = new HocVien("SV02", "Tran Van B", "Hue",
                new double[] { 7.0, 7.0, 7.0 });


            Assert.IsFalse(hv.DatHocBong());
        }

        [TestMethod]
        public void DatHocBong_HasSubjectBelowFive_ReturnsFalse()
        {
            var hv = new HocVien("SV03", "Le Van C", "Da Nang",
                new double[] { 9.0, 4.0, 9.0 });

            Assert.IsFalse(hv.DatHocBong());
        }

        [TestMethod]
        public void TrungTamGiaSu_FilterScholarshipStudents_ReturnsCorrectList()
        {
            var hv1 = new HocVien("SV01", "A", "HN", new double[] { 8, 9, 8 }); // đạt
            var hv2 = new HocVien("SV02", "B", "HN", new double[] { 7, 7, 7 }); // không đạt
            var hv3 = new HocVien("SV03", "C", "HN", new double[] { 9, 9, 9 }); // đạt


            var trungTam = new TrungTamGiaSu(new List<HocVien> { hv1, hv2, hv3 });

            var result = trungTam.LayDanhSachHocBong();

            Assert.AreEqual(2, result.Count);
            CollectionAssert.Contains(result, hv1);
            CollectionAssert.Contains(result, hv3);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Constructor_InvalidScoreArray_ThrowsException()
        {
            var hv = new HocVien("SV04", "D", "HN", new double[] { 9, 8 });
        }
    }
}

