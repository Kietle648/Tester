﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using Bai2_Buoi4;

namespace Bai2_Buoi4.Tests
{
    [TestClass]
    public class PolynomialTests
    {
        // Test đúng dữ liệu
        [TestMethod]
        public void Cal_ValidPolynomial_ReturnsCorrectValue()
        {
            // f(x) = 1 + 2x + 3x^2, x = 2 → 1 + 4 + 12 = 17
            var a = new List<int> { 1, 2, 3 };
            Polynomial p = new Polynomial(2, a);

            int result = p.Cal(2);

            Assert.AreEqual(17, result);
        }

        // Test thiếu hệ số
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Constructor_NotEnoughCoefficients_ThrowsException()
        {
            var a = new List<int> { 1, 2 }; // thiếu 1 hệ số
            Polynomial p = new Polynomial(2, a);
        }

        // Test n âm
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Constructor_NegativeDegree_ThrowsException()
        {
            var a = new List<int> { 1 };
            Polynomial p = new Polynomial(-1, a);
        }
    }
}
