﻿using Bai_Buoi4;
using Bai1_Buoi4;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bai_Buoi4.Tests
{
    [TestClass]
    public class PowerTests
    {
        [TestMethod]
        public void Power_N_Equals_Zero()
        {
            Assert.AreEqual(1.0, MathHelper.Power(5, 0));
        }

        [TestMethod]
        public void Power_N_Positive()
        {
            Assert.AreEqual(8.0, MathHelper.Power(2, 3));
        }

        [TestMethod]
        public void Power_N_Negative()
        {
            Assert.AreEqual(0.25, MathHelper.Power(2, -2));
        }

        [TestMethod]
        public void Power_X_Equals_One()
        {
            Assert.AreEqual(1.0, MathHelper.Power(1, 100));
        }

        [TestMethod]
        public void Power_X_Equals_Zero()
        {
            Assert.AreEqual(0.0, MathHelper.Power(0, 5));
        }
    }
}
