﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Bai3_Buoi4;

namespace Bai3_Buoi4.Tests
{
    [TestClass]
    public class RadixTests
    {
        // Test chuyển sang nhị phân
        [TestMethod]
        public void Convert_ToBinary_ReturnsCorrect()
        {
            Radix r = new Radix(10);
            string result = r.ConvertDecimalToAnother(2);

            Assert.AreEqual("1010", result);
        }

        // Test chuyển sang hệ 16
        [TestMethod]
        public void Convert_ToHex_ReturnsCorrect()
        {
            Radix r = new Radix(255);
            string result = r.ConvertDecimalToAnother(16);

            Assert.AreEqual("FF", result);
        }

        // Test radix không hợp lệ
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Convert_InvalidRadix_ThrowsException()
        {
            Radix r = new Radix(10);
            r.ConvertDecimalToAnother(20);
        }

        // Test số âm
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Constructor_NegativeNumber_ThrowsException()
        {
            Radix r = new Radix(-5);
        }
    }
}
