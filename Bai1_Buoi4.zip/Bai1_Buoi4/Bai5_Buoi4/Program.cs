﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai5_Buoi4
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
