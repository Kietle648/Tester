﻿using System.Collections.Generic;
using System.Linq;

namespace Bai5_Buoi4
{
    public class TrungTamGiaSu
    {
        public List<HocVien> DanhSachHocVien { get; }

        public TrungTamGiaSu(List<HocVien> hocViens)
        {
            DanhSachHocVien = hocViens;
        }

        public List<HocVien> LayDanhSachHocBong()
        {
            return DanhSachHocVien.Where(hv => hv.DatHocBong()).ToList();
        }
    }
}
