﻿using System;
using System.Linq;

namespace Bai5_Buoi4
{
    public class HocVien
    {
        public string MaSo { get; }
        public string HoTen { get; }
        public string QueQuan { get; }
        public double[] Diem { get; }

        public HocVien(string maSo, string hoTen, string queQuan, double[] diem)
        {
            if (diem == null || diem.Length != 3)
                throw new ArgumentException("Invalid Score Data");

            MaSo = maSo;
            HoTen = hoTen;
            QueQuan = queQuan;
            Diem = diem;
        }

        public double DiemTrungBinh()
        {
            return Diem.Average();
        }

        public bool DatHocBong()
        {
            return DiemTrungBinh() >= 8.0 && Diem.All(d => d >= 5.0);
        }
    }
}
