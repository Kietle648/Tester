﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace OrgWinForms
{
    public partial class Form1 : Form
    {
        string connectionString =
            "Server=DESKTOP-D6KN1UQ\\SQLSV_CON1;Database=OrgManagement;Trusted_Connection=True;";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter da =
                    new SqlDataAdapter("SELECT * FROM ORGANIZATION", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvOrg.DataSource = dt;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtOrgName.Text))
            {
                MessageBox.Show("Tên tổ chức không được để trống");
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string sql = @"INSERT INTO ORGANIZATION
                                  (OrgName, Address, Phone, Email)
                                  VALUES (@OrgName, @Address, @Phone, @Email)";

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@OrgName", txtOrgName.Text.Trim());
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Thêm tổ chức thành công!");
                ClearForm();
                LoadData();
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2601 || ex.Number == 2627)
                {
                    MessageBox.Show("Tên tổ chức đã tồn tại!");
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void ClearForm()
        {
            txtOrgName.Clear();
            txtAddress.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
        }

        private void dgvOrg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
