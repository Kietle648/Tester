﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace OrgWinForms
{
    public partial class Form1 : Form
    {
        // Label hiển thị lỗi
        Label lblOrgErr = new Label();
        Label lblPhoneErr = new Label();
        Label lblEmailErr = new Label();

        public Form1()
        {
            InitializeComponent();
        }

        // ================= FORM LOAD =================

        private void Form1_Load(object sender, EventArgs e)
        {
            InitErrorLabels();
            LoadData();
        }

        // ================= INIT ERROR LABEL =================

        void InitErrorLabels()
        {
            SetupLabel(lblOrgErr, txtOrgName);
            SetupLabel(lblPhoneErr, txtPhone);
            SetupLabel(lblEmailErr, txtEmail);
        }

        void SetupLabel(Label lbl, Control txt)
        {
            lbl.ForeColor = System.Drawing.Color.Red;
            lbl.AutoSize = true;
            lbl.Left = txt.Left;
            lbl.Top = txt.Bottom + 3;
            lbl.Text = "";
            this.Controls.Add(lbl);
        }

        // ================= LOAD DATA =================

        void LoadData()
        {
            using (SqlConnection conn =
                new SqlConnection(DBHelper.ConnStr))
            {
                SqlDataAdapter da =
                    new SqlDataAdapter("SELECT * FROM ORGANIZATION", conn);

                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvOrg.DataSource = dt;
            }
        }

        // ================= VALIDATE =================

        bool ValidateInput()
        {
            // Clear lỗi cũ
            lblOrgErr.Text = "";
            lblPhoneErr.Text = "";
            lblEmailErr.Text = "";

            bool ok = true;

            // ---- OrgName ----
            if (string.IsNullOrWhiteSpace(txtOrgName.Text))
            {
                lblOrgErr.Text = "Tên tổ chức không được để trống";
                ok = false;
            }
            else if (txtOrgName.Text.Length < 3)
            {
                lblOrgErr.Text = "Tên tổ chức ít nhất 3 ký tự";
                ok = false;
            }

            // ---- Phone ----
            if (string.IsNullOrWhiteSpace(txtPhone.Text))
            {
                lblPhoneErr.Text = "Số điện thoại không được để trống";
                ok = false;
            }
            else if (!Regex.IsMatch(txtPhone.Text, @"^\d{9,12}$"))
            {
                lblPhoneErr.Text = "Số điện thoại phải từ 9-12 chữ số";
                ok = false;
            }

            // ---- Email ----
            if (!string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                try
                {
                    var mail = new System.Net.Mail.MailAddress(txtEmail.Text);
                }
                catch
                {
                    lblEmailErr.Text = "Email không hợp lệ";
                    ok = false;
                }
            }

            return ok;
        }

        // ================= CHECK DUPLICATE =================

        bool IsOrgNameExists(string name)
        {
            using (SqlConnection conn =
                new SqlConnection(DBHelper.ConnStr))
            {
                conn.Open();

                SqlCommand cmd =
                    new SqlCommand(
                        "SELECT COUNT(*) FROM ORGANIZATION WHERE OrgName=@n",
                        conn);

                cmd.Parameters.AddWithValue("@n", name);

                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        // ================= SAVE =================

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInput())
                return;

            if (IsOrgNameExists(txtOrgName.Text))
            {
                lblOrgErr.Text = "Tên tổ chức đã tồn tại";
                return;
            }

            using (SqlConnection conn =
                new SqlConnection(DBHelper.ConnStr))
            {
                conn.Open();

                SqlCommand cmd =
                    new SqlCommand(@"
                        INSERT INTO ORGANIZATION
                        (OrgName, Address, Phone, Email)
                        VALUES (@n,@a,@p,@e)", conn);

                cmd.Parameters.AddWithValue("@n", txtOrgName.Text);
                cmd.Parameters.AddWithValue("@a", txtAddress.Text);
                cmd.Parameters.AddWithValue("@p", txtPhone.Text);
                cmd.Parameters.AddWithValue("@e", txtEmail.Text);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Lưu dữ liệu thành công!");

            ClearForm();
            LoadData();
        }

        // ================= CLEAR =================

        void ClearForm()
        {
            txtOrgName.Clear();
            txtAddress.Clear();
            txtPhone.Clear();
            txtEmail.Clear();

            lblOrgErr.Text = "";
            lblPhoneErr.Text = "";
            lblEmailErr.Text = "";
        }
    }
}
