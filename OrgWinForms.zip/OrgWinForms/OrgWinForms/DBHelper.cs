﻿using System.Data;
using System.Data.SqlClient;

namespace OrgWinForms
{
    public class DBHelper
    {
        public static string ConnStr =
            "Server=DESKTOP-D6KN1UQ\\SQLSV_CON1;" +
            "Database=OrganizationDB;" +
            "User Id=sa;" +
            "Password=123;" +
            "TrustServerCertificate=True;";
    }
}
