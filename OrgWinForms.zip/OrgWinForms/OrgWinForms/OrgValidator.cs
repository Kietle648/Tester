﻿using System.Text.RegularExpressions;

namespace OrgWinForms
{
    public static class OrgValidator
    {
        public static bool IsValidOrgName(string name)
        {
            return !string.IsNullOrWhiteSpace(name)
                   && name.Trim().Length >= 3;
        }

        public static bool IsValidPhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone))
                return false;

            return Regex.IsMatch(phone, @"^\d{9,12}$");
        }

        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return true; // Email được phép trống

            try
            {
                var m = new System.Net.Mail.MailAddress(email);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
