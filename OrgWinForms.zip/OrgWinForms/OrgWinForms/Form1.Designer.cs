﻿namespace OrgWinForms
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        // Labels
        private System.Windows.Forms.Label lblOrg;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblEmail;

        // Textbox
        private System.Windows.Forms.TextBox txtOrgName;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtEmail;

        // Buttons
        private System.Windows.Forms.Button btnSave;

        // Grid
        private System.Windows.Forms.DataGridView dgvOrg;

        // Error Summary
        private System.Windows.Forms.Label lblErrors;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblOrg = new System.Windows.Forms.Label();
            lblAddress = new System.Windows.Forms.Label();
            lblPhone = new System.Windows.Forms.Label();
            lblEmail = new System.Windows.Forms.Label();

            txtOrgName = new System.Windows.Forms.TextBox();
            txtAddress = new System.Windows.Forms.TextBox();
            txtPhone = new System.Windows.Forms.TextBox();
            txtEmail = new System.Windows.Forms.TextBox();

            btnSave = new System.Windows.Forms.Button();
            dgvOrg = new System.Windows.Forms.DataGridView();
            lblErrors = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(dgvOrg)).BeginInit();
            SuspendLayout();

            // ===== LEFT COLUMN =====
            lblOrg.Text = "Organization Name *";
            lblOrg.Location = new System.Drawing.Point(30, 20);

            txtOrgName.Location = new System.Drawing.Point(30, 40);
            txtOrgName.Width = 250;

            lblAddress.Text = "Address";
            lblAddress.Location = new System.Drawing.Point(30, 80);

            txtAddress.Location = new System.Drawing.Point(30, 100);
            txtAddress.Width = 250;

            // ===== RIGHT COLUMN =====
            lblPhone.Text = "Phone Number *";
            lblPhone.Location = new System.Drawing.Point(320, 20);

            txtPhone.Location = new System.Drawing.Point(320, 40);
            txtPhone.Width = 250;

            lblEmail.Text = "Email";
            lblEmail.Location = new System.Drawing.Point(320, 80);

            txtEmail.Location = new System.Drawing.Point(320, 100);
            txtEmail.Width = 250;

            // ===== SAVE BUTTON =====
            btnSave.Text = "Save";
            btnSave.Location = new System.Drawing.Point(30, 150);
            btnSave.Width = 120;
            btnSave.Click += btnSave_Click;

            // ===== GRID =====
            dgvOrg.Location = new System.Drawing.Point(30, 190);
            dgvOrg.Size = new System.Drawing.Size(540, 200);

            // ===== ERROR SUMMARY =====
            lblErrors.ForeColor = System.Drawing.Color.Red;
            lblErrors.Location = new System.Drawing.Point(30, 400);
            lblErrors.Size = new System.Drawing.Size(540, 100);
            lblErrors.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            // ===== FORM =====
            ClientSize = new System.Drawing.Size(620, 530);
            Text = "Organisation Details";

            Controls.Add(lblOrg);
            Controls.Add(txtOrgName);
            Controls.Add(lblAddress);
            Controls.Add(txtAddress);

            Controls.Add(lblPhone);
            Controls.Add(txtPhone);
            Controls.Add(lblEmail);
            Controls.Add(txtEmail);

            Controls.Add(btnSave);
            Controls.Add(dgvOrg);
            Controls.Add(lblErrors);

            Load += Form1_Load;

            ((System.ComponentModel.ISupportInitialize)(dgvOrg)).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
