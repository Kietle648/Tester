﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrgWinForms;

namespace OrgWinForms.Tests
{
    [TestClass]
    public class OrgTests
    {
        // ========= ORG NAME =========

        [TestMethod] // TC01
        public void OrgName_Valid()
        {
            Assert.IsTrue(OrgValidator.IsValidOrgName("ABC Company"));
        }

        [TestMethod] // TC02
        public void OrgName_Empty()
        {
            Assert.IsFalse(OrgValidator.IsValidOrgName(""));
        }

        [TestMethod] // TC03
        public void OrgName_Spaces()
        {
            Assert.IsFalse(OrgValidator.IsValidOrgName("   "));
        }

        [TestMethod] // TC04
        public void OrgName_Length2()
        {
            Assert.IsFalse(OrgValidator.IsValidOrgName("AB"));
        }

        [TestMethod] // TC05
        public void OrgName_Length3()
        {
            Assert.IsTrue(OrgValidator.IsValidOrgName("ABC"));
        }

        // ========= PHONE =========

        [TestMethod] // TC06
        public void Phone_Valid()
        {
            Assert.IsTrue(OrgValidator.IsValidPhone("0987654321"));
        }

        [TestMethod] // TC07
        public void Phone_HasLetters()
        {
            Assert.IsFalse(OrgValidator.IsValidPhone("abc123"));
        }

        [TestMethod] // TC08
        public void Phone_TooShort()
        {
            Assert.IsFalse(OrgValidator.IsValidPhone("12345678"));
        }

        [TestMethod] // TC09
        public void Phone_9Digits()
        {
            Assert.IsTrue(OrgValidator.IsValidPhone("123456789"));
        }

        [TestMethod] // TC10
        public void Phone_12Digits()
        {
            Assert.IsTrue(OrgValidator.IsValidPhone("012345678901"));
        }

        [TestMethod] // TC11
        public void Phone_TooLong()
        {
            Assert.IsFalse(OrgValidator.IsValidPhone("0123456789012"));
        }

        // ========= EMAIL =========

        [TestMethod] // TC12
        public void Email_Valid()
        {
            Assert.IsTrue(OrgValidator.IsValidEmail("abc@gmail.com"));
        }

        [TestMethod] // TC13
        public void Email_Invalid()
        {
            Assert.IsFalse(OrgValidator.IsValidEmail("abc@@gmail"));
        }

        [TestMethod] // TC14
        public void Email_Empty()
        {
            Assert.IsTrue(OrgValidator.IsValidEmail(""));
        }

        // ========= COMBINATION =========

        [TestMethod] // TC15
        public void AllValid()
        {
            bool ok =
                OrgValidator.IsValidOrgName("Company") &&
                OrgValidator.IsValidPhone("0987654321") &&
                OrgValidator.IsValidEmail("abc@gmail.com");

            Assert.IsTrue(ok);
        }

        [TestMethod] // TC16
        public void OrgInvalid_AllFail()
        {
            bool ok =
                OrgValidator.IsValidOrgName("") &&
                OrgValidator.IsValidPhone("12") &&
                OrgValidator.IsValidEmail("xxx");

            Assert.IsFalse(ok);
        }

        // ========= FLOW TEST (LOGIC) =========

        [TestMethod] // TC17
        public void SaveFlow_Simulated()
        {
            bool canSave =
                OrgValidator.IsValidOrgName("ABC") &&
                OrgValidator.IsValidPhone("0987654321");

            Assert.IsTrue(canSave);
        }

        [TestMethod] // TC18
        public void BackFlow_AlwaysTrue()
        {
            bool backPressed = true;
            Assert.IsTrue(backPressed);
        }
    }
}
