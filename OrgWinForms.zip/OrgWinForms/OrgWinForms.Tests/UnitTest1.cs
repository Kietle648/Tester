﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace OrgWinForms.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
