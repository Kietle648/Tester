package dtm;

import org.testng.Assert;
import org.testng.annotations.Test;
import vn.shopvn.GiamGia;

public class GiamGiaTest {
    @Test
    public void testCase1() {
        Assert.assertTrue(GiamGia.duocGiamGia(true, 600000, false));
    }

    @Test
    public void testCase2() {
        Assert.assertFalse(GiamGia.duocGiamGia(true, 400000, false));
    }

    @Test
    public void testCase3() {
        Assert.assertFalse(false);
    }

    @Test
    public void testCase4() {
        Assert.assertTrue(true);
    }
}
