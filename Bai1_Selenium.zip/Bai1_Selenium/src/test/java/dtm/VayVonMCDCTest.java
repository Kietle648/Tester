package dtm;

import org.testng.Assert;
import org.testng.annotations.Test;
import vn.shopvn.VayVon;

public class VayVonMCDCTest {

    @Test(description = "MC/DC - Dieu kien tuoi doc lap")
    public void testMCDC_TuoiDocLap() {
        boolean actual = VayVon.duDieuKienVay(20, 12_000_000, true, 650);
        Assert.assertFalse(actual,
                "Tuoi < 22 thi khong du dieu kien vay");
    }

    @Test(description = "MC/DC - Dieu kien thu nhap doc lap")
    public void testMCDC_ThuNhapDocLap() {
        boolean actual = VayVon.duDieuKienVay(25, 8_000_000, true, 650);
        Assert.assertFalse(actual,
                "Thu nhap < 10 trieu thi khong du dieu kien vay");
    }

    @Test(description = "MC/DC - Dieu kien tai san bao lanh doc lap")
    public void testMCDC_TaiSanDocLap() {
        boolean actual = VayVon.duDieuKienVay(25, 12_000_000, false, 650);
        Assert.assertFalse(actual,
                "Khong co tai san va diem tin dung thap thi khong du dieu kien vay");
    }

    @Test(description = "MC/DC - Dieu kien diem tin dung doc lap")
    public void testMCDC_DiemTinDungDocLap() {
        boolean actual = VayVon.duDieuKienVay(25, 12_000_000, false, 750);
        Assert.assertTrue(actual,
                "Diem tin dung >= 700 thi du dieu kien vay khi cac dieu kien khac hop le");
    }

    @Test(description = "MC/DC - Truong hop co so de so sanh")
    public void testMCDC_BaseCase() {
        boolean actual = VayVon.duDieuKienVay(25, 12_000_000, true, 650);
        Assert.assertTrue(actual,
                "Truong hop co so phai du dieu kien vay");
    }
}