package dtm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.TextBoxPage;

public class TextBoxWhiteBoxTest {

    WebDriver driver;
    TextBoxPage page;

    @BeforeMethod
    public void setup() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://demoqa.com/text-box");

        page = new TextBoxPage(driver);
    }

    @Test
    public void testValidInput() {

        page.fillAndSubmit("Nguyen Van A",
                "test@gmail.com",
                "Ho Chi Minh");

        Assert.assertTrue(page.getOutputText().contains("Nguyen Van A"));
    }

    @Test
    public void testInvalidEmail() {

        page.fillAndSubmit("Nguyen",
                "invalidEmail",
                "HCM");

        Assert.assertFalse(page.getOutputText().contains("invalidEmail"));
    }

    @Test
    public void testEmptyName() {

        page.fillAndSubmit("",
                "test@gmail.com",
                "HCM");

        Assert.assertFalse(page.getOutputText().contains("Name"));
    }

    @AfterMethod
    public void teardown() {
        driver.quit();
    }
}