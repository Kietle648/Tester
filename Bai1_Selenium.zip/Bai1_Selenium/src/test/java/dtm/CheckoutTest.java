package dtm;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CheckoutTest {
    WebDriver driver;

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com");

        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();

        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        driver.findElement(By.className("shopping_cart_link")).click();
        driver.findElement(By.id("checkout")).click();
    }

    @Test(groups = {"smoke", "regression"})
    public void testCheckoutPageDisplayed() {
        Assert.assertTrue(driver.getCurrentUrl().contains("checkout-step-one.html"),
                "Khong mo duoc trang checkout!");
    }

    @Test(groups = {"regression"})
    public void testCheckoutFormDisplayed() {
        Assert.assertTrue(driver.findElement(By.id("first-name")).isDisplayed(),
                "O First Name khong hien thi!");
        Assert.assertTrue(driver.findElement(By.id("last-name")).isDisplayed(),
                "O Last Name khong hien thi!");
        Assert.assertTrue(driver.findElement(By.id("postal-code")).isDisplayed(),
                "O Postal Code khong hien thi!");
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}