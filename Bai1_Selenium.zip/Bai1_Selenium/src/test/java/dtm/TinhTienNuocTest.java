package dtm;

import org.testng.Assert;
import org.testng.annotations.Test;
import vn.shopvn.TinhTienNuoc;

public class TinhTienNuocTest {

    @Test(description = "TC1 - So m3 <= 0")
    public void testSoM3KhongHopLe() {
        double actual = TinhTienNuoc.tinhTienNuoc(0, "dan_cu");
        Assert.assertEquals(actual, 0.0, "So m3 <= 0 phai tra ve 0");
    }

    @Test(description = "TC2 - Ho ngheo")
    public void testHoNgheo() {
        double actual = TinhTienNuoc.tinhTienNuoc(5, "ho_ngheo");
        Assert.assertEquals(actual, 25000.0, "Tien nuoc ho ngheo tinh sai");
    }

    @Test(description = "TC3 - Dan cu <= 10m3")
    public void testDanCuMuc1() {
        double actual = TinhTienNuoc.tinhTienNuoc(8, "dan_cu");
        Assert.assertEquals(actual, 60000.0, "Tien nuoc dan cu muc <= 10 tinh sai");
    }

    @Test(description = "TC4 - Dan cu tu 11 den 20m3")
    public void testDanCuMuc2() {
        double actual = TinhTienNuoc.tinhTienNuoc(15, "dan_cu");
        Assert.assertEquals(actual, 148500.0, "Tien nuoc dan cu muc 11-20 tinh sai");
    }

    @Test(description = "TC5 - Dan cu > 20m3")
    public void testDanCuMuc3() {
        double actual = TinhTienNuoc.tinhTienNuoc(25, "dan_cu");
        Assert.assertEquals(actual, 285000.0, "Tien nuoc dan cu muc > 20 tinh sai");
    }

    @Test(description = "TC6 - Kinh doanh")
    public void testKinhDoanh() {
        double actual = TinhTienNuoc.tinhTienNuoc(25, "kinh_doanh");
        Assert.assertEquals(actual, 550000.0, "Tien nuoc kinh doanh tinh sai");
    }
}