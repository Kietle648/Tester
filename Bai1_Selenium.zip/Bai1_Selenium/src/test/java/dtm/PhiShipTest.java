package dtm;

import org.testng.Assert;
import org.testng.annotations.Test;
import vn.shopvn.PhiShip;

public class PhiShipTest {

    @Test(expectedExceptions = IllegalArgumentException.class)
    public void testInvalidWeight() {
        PhiShip.tinhPhiShip(-1, "noi_thanh", false);
    }

    @Test
    public void testNoiThanhBasic() {
        Assert.assertEquals(PhiShip.tinhPhiShip(4, "noi_thanh", false), 15000);
    }

    @Test
    public void testNoiThanhExtra() {
        Assert.assertEquals(PhiShip.tinhPhiShip(7, "noi_thanh", false), 19000);
    }

    @Test
    public void testNgoaiThanhBasic() {
        Assert.assertEquals(PhiShip.tinhPhiShip(2, "ngoai_thanh", false), 25000);
    }

    @Test
    public void testNgoaiThanhExtra() {
        Assert.assertEquals(PhiShip.tinhPhiShip(6, "ngoai_thanh", false), 34000);
    }

    @Test
    public void testTinhKhacBasic() {
        Assert.assertEquals(PhiShip.tinhPhiShip(1, "tinh_khac", false), 50000);
    }

    @Test
    public void testTinhKhacExtra() {
        Assert.assertEquals(PhiShip.tinhPhiShip(5, "tinh_khac", false), 65000);
    }

    @Test
    public void testMemberDiscount() {
        Assert.assertEquals(PhiShip.tinhPhiShip(5, "noi_thanh", true), 13500);
    }
}