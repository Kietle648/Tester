package dtm;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class LoginTest {
    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com");
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }



    public void login(String username, String password) {
        WebElement usernameField = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("user-name")));
        WebElement passwordField = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        WebElement loginButton = wait.until(
                ExpectedConditions.elementToBeClickable(By.id("login-button")));

        usernameField.clear();
        usernameField.sendKeys(username);

        passwordField.clear();
        passwordField.sendKeys(password);

        loginButton.click();
    }

    @Test(groups = {"smoke", "regression"})
    public void testLoginSuccess() {
        login("standard_user", "secret_sauce");
        wait.until(ExpectedConditions.urlContains("inventory.html"));
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory.html"),
                "Dang nhap thanh cong nhung khong chuyen den trang inventory!");
    }

    @Test(groups = {"regression"})
    public void testLoginWrongPassword() {
        login("standard_user", "wrong_password");
        WebElement errorMessage = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[data-test='error']")));
        Assert.assertTrue(errorMessage.isDisplayed(),
                "Khong hien thi thong bao loi khi nhap sai mat khau!");
    }

    @Test(groups = {"regression"})
    public void testLoginEmptyUsername() {
        login("", "secret_sauce");
        WebElement errorMessage = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[data-test='error']")));
        Assert.assertTrue(errorMessage.getText().contains("Username is required"),
                "Thong bao loi khi de trong username khong dung!");
    }

    @Test(groups = {"regression"})
    public void testLoginEmptyPassword() {
        login("standard_user", "");
        WebElement errorMessage = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[data-test='error']")));
        Assert.assertTrue(errorMessage.getText().contains("Password is required"),
                "Thong bao loi khi de trong password khong dung!");
    }

    @Test(groups = {"regression"})
    public void testLoginLockedUser() {
        login("locked_out_user", "secret_sauce");
        WebElement errorMessage = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[data-test='error']")));
        Assert.assertTrue(errorMessage.getText().contains("Sorry, this user has been locked out"),
                "Thong bao loi tai khoan bi khoa khong dung!");
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}