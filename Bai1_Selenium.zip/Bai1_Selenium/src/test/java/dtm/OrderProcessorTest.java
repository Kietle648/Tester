package dtm;

import org.testng.Assert;
import org.testng.annotations.Test;
import vn.shopvn.Item;
import vn.shopvn.OrderProcessor;

import java.util.Arrays;
import java.util.List;

public class OrderProcessorTest {

    private final OrderProcessor orderProcessor = new OrderProcessor();

    private List<Item> items(double... prices) {
        return Arrays.stream(prices).mapToObj(Item::new).toList();
    }

    @Test(description = "P1 - Gio hang trong", expectedExceptions = IllegalArgumentException.class)
    public void testPath1_EmptyCart() {
        orderProcessor.calculateTotal(null, null, "NONE", "COD");
    }

    @Test(description = "P2 - Khong coupon, khong member, COD, co ship")
    public void testPath2_NoCouponNoMember_COD() {
        double actual = orderProcessor.calculateTotal(items(100000, 100000), null, "NONE", "COD");
        Assert.assertEquals(actual, 220000.0, 0.01, "Tong tien tinh sai cho path 2");
    }

    @Test(description = "P3 - Khong coupon, khong member, online, co ship")
    public void testPath3_NoCouponNoMember_Online() {
        double actual = orderProcessor.calculateTotal(items(100000, 100000), null, "NONE", "BANK");
        Assert.assertEquals(actual, 230000.0, 0.01, "Tong tien tinh sai cho path 3");
    }

    @Test(description = "P4 - Coupon SALE10, COD")
    public void testPath4_Sale10_COD() {
        double actual = orderProcessor.calculateTotal(items(100000, 100000), "SALE10", "NONE", "COD");
        Assert.assertEquals(actual, 200000.0, 0.01, "Tong tien tinh sai cho path 4");
    }

    @Test(description = "P5 - Coupon SALE20, online")
    public void testPath5_Sale20_Online() {
        double actual = orderProcessor.calculateTotal(items(100000, 100000), "SALE20", "NONE", "BANK");
        Assert.assertEquals(actual, 190000.0, 0.01, "Tong tien tinh sai cho path 5");
    }

    @Test(description = "P6 - Coupon khong hop le", expectedExceptions = IllegalArgumentException.class)
    public void testPath6_InvalidCoupon() {
        orderProcessor.calculateTotal(items(100000), "ABC", "NONE", "COD");
    }

    @Test(description = "P7 - Member GOLD")
    public void testPath7_GoldMember() {
        double actual = orderProcessor.calculateTotal(items(100000, 100000), null, "GOLD", "COD");
        Assert.assertEquals(actual, 210000.0, 0.01, "Tong tien tinh sai cho path 7");
    }

    @Test(description = "P8 - Member PLATINUM")
    public void testPath8_PlatinumMember() {
        double actual = orderProcessor.calculateTotal(items(100000, 100000), null, "PLATINUM", "BANK");
        Assert.assertEquals(actual, 210000.0, 0.01, "Tong tien tinh sai cho path 8");
    }

    @Test(description = "P9 - Tong tien >= 500000, khong tinh ship")
    public void testPath9_NoShipping() {
        double actual = orderProcessor.calculateTotal(items(300000, 300000), null, "NONE", "BANK");
        Assert.assertEquals(actual, 600000.0, 0.01, "Tong tien tinh sai cho path 9");
    }

    @Test(description = "MC/DC D2 - couponCode null")
    public void testMcdcD2_NullCoupon() {
        double actual = orderProcessor.calculateTotal(items(100000, 100000), null, "NONE", "COD");
        Assert.assertEquals(actual, 220000.0, 0.01, "Case null coupon tinh sai");
    }

    @Test(description = "MC/DC D2 - couponCode rong")
    public void testMcdcD2_EmptyCoupon() {
        double actual = orderProcessor.calculateTotal(items(100000, 100000), "", "NONE", "COD");
        Assert.assertEquals(actual, 220000.0, 0.01, "Case empty coupon tinh sai");
    }

    @Test(description = "MC/DC D2 - couponCode hop le")
    public void testMcdcD2_ValidCoupon() {
        double actual = orderProcessor.calculateTotal(items(100000, 100000), "SALE10", "NONE", "COD");
        Assert.assertEquals(actual, 200000.0, 0.01, "Case valid coupon tinh sai");
    }
}