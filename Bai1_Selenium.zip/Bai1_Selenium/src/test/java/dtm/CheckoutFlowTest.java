package dtm;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CheckoutFlowTest {

    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com");
    }

    @Test
    public void testCheckoutFlow() {

        // Login
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();

        // Verify inventory page
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"));

        // Add product
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();

        // Open cart
        driver.findElement(By.className("shopping_cart_link")).click();

        // Verify cart page
        Assert.assertTrue(driver.getCurrentUrl().contains("cart"));

        // Checkout
        driver.findElement(By.id("checkout")).click();

        // Fill information
        driver.findElement(By.id("first-name")).sendKeys("Nguyen");
        driver.findElement(By.id("last-name")).sendKeys("Test");
        driver.findElement(By.id("postal-code")).sendKeys("700000");

        driver.findElement(By.id("continue")).click();

        // Finish order
        driver.findElement(By.id("finish")).click();

        // Verify success
        String successMessage = driver.findElement(By.className("complete-header")).getText();

        Assert.assertEquals(successMessage, "Thank you for your order!");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}