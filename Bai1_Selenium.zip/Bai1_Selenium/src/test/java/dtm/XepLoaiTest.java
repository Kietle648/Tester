package dtm;

import org.testng.Assert;
import org.testng.annotations.Test;
import vn.shopvn.XepLoai;

public class XepLoaiTest {

    @Test(description = "TC1 - Diem khong hop le")
    public void testInvalidScore() {
        String actual = XepLoai.xepLoai(-1, false);
        Assert.assertEquals(actual, "Diem khong hop le",
                "Diem am phai tra ve 'Diem khong hop le'");
    }

    @Test(description = "TC2 - Xep loai Gioi")
    public void testGioi() {
        String actual = XepLoai.xepLoai(9.0, false);
        Assert.assertEquals(actual, "Gioi",
                "Diem >= 8.5 phai xep loai Gioi");
    }

    @Test(description = "TC3 - Xep loai Kha")
    public void testKha() {
        String actual = XepLoai.xepLoai(7.5, false);
        Assert.assertEquals(actual, "Kha",
                "Diem tu 7.0 den duoi 8.5 phai xep loai Kha");
    }

    @Test(description = "TC4 - Xep loai Trung Binh")
    public void testTrungBinh() {
        String actual = XepLoai.xepLoai(6.0, false);
        Assert.assertEquals(actual, "Trung Binh",
                "Diem tu 5.5 den duoi 7.0 phai xep loai Trung Binh");
    }

    @Test(description = "TC5 - Thi lai")
    public void testThiLai() {
        String actual = XepLoai.xepLoai(4.0, true);
        Assert.assertEquals(actual, "Thi lai",
                "Diem duoi 5.5 va co thi lai phai tra ve 'Thi lai'");
    }

    @Test(description = "TC6 - Yeu Hoc lai")
    public void testYeuHocLai() {
        String actual = XepLoai.xepLoai(4.0, false);
        Assert.assertEquals(actual, "Yeu - Hoc lai",
                "Diem duoi 5.5 va khong thi lai phai tra ve 'Yeu - Hoc lai'");
    }
}