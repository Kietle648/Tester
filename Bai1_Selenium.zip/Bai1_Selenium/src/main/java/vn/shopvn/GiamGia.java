package vn.shopvn;

public class GiamGia {
    public static boolean duocGiamGia(boolean laMember, int tongTien, boolean ngayLe) {
        if ((laMember && tongTien > 500000) || ngayLe) {
            return true;
        }
        return false;
    }
}
